// Copyright (c) 2026 SirotkinAleksandr. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
class SGSCPPV4_API SGSCppV4Prj
{
public:
	SGSCppV4Prj();
	~SGSCppV4Prj();
};
