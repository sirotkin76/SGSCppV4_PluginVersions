// Fill out your copyright notice in the Description page of Project Settings.


#include "SGSCppV4Prj.h"

SGSCppV4Prj::SGSCppV4Prj()
{
}

SGSCppV4Prj::~SGSCppV4Prj()
{
}
